﻿HydroFlowManager backend - .NET 8 Minimal API. Run: dotnet restore -> dotnet build -> dotnet run
