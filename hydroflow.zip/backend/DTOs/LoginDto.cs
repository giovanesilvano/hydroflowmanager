﻿namespace HydroFlowManager.API.DTOs { public class LoginDto { public string CPF { get; set; } = null!; public string Password { get; set; } = null!; } }
