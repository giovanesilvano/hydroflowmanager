﻿Frontend Vite+React. Run: npm install && npm run dev
