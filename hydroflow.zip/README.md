﻿HydroFlow Manager - pacote gerado localmente. Ver pastas backend/ e frontend/.
